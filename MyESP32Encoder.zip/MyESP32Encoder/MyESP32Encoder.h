#ifndef MY_ESP32_ENCODER_H
#define MY_ESP32_ENCODER_H

#include <Arduino.h>

class MyESP32Encoder {
public:
  MyESP32Encoder(uint8_t pinA, uint8_t pinB, uint8_t buttonPin);

  void begin();
  int getValue();
  void reset();
  bool wasButtonPressed();

private:
  uint8_t _pinA, _pinB, _buttonPin;
  volatile int _value;
  volatile bool _lastA;
  volatile bool _buttonPressed;
  static MyESP32Encoder* instance;

  static void IRAM_ATTR isrA();
  static void IRAM_ATTR isrButton();

  void handleEncoder();
  void handleButton();
};

#endif
