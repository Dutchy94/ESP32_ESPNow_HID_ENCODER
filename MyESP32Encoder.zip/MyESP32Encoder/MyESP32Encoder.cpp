#include "MyESP32Encoder.h"

MyESP32Encoder* MyESP32Encoder::instance = nullptr;

MyESP32Encoder::MyESP32Encoder(uint8_t pinA, uint8_t pinB, uint8_t buttonPin)
  : _pinA(pinA), _pinB(pinB), _buttonPin(buttonPin), _value(0),
    _lastA(false), _buttonPressed(false) {
  // instance wird jetzt in begin() gesetzt
}

void MyESP32Encoder::begin() {
  pinMode(_pinA, INPUT_PULLUP);
  pinMode(_pinB, INPUT_PULLUP);
  pinMode(_buttonPin, INPUT_PULLUP);

  _lastA = digitalRead(_pinA);

  instance = this;  // Jetzt sicher hier setzen!

  attachInterrupt(digitalPinToInterrupt(_pinA), isrA, CHANGE);
  attachInterrupt(digitalPinToInterrupt(_buttonPin), isrButton, FALLING);
}

int MyESP32Encoder::getValue() {
	if (!instance) return 0;
	noInterrupts();
	int val = _value;
	interrupts();
	return val;
}

void MyESP32Encoder::reset() {
  _value = 0;
}

bool MyESP32Encoder::wasButtonPressed() {
  bool pressed = _buttonPressed;
  _buttonPressed = false;
  return pressed;
}

void IRAM_ATTR MyESP32Encoder::isrA() {
  if (instance) instance->handleEncoder();
}

void IRAM_ATTR MyESP32Encoder::isrButton() {
  if (instance) instance->handleButton();
}

void MyESP32Encoder::handleEncoder() {
  bool A = digitalRead(_pinA);
  bool B = digitalRead(_pinB);

  if (A != _lastA) {
    if (B != A) _value++;
    else        _value--;
    _lastA = A;
  }
}

void MyESP32Encoder::handleButton() {
  _buttonPressed = true;
}
